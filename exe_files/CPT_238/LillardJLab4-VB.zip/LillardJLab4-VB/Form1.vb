﻿Option Strict On
Option Explicit On
'CPT212 Chapter 4 PieceWork'
'Calculating workers pay based off number of pieces'
'Programmed By: Gavin Lillard'


Public Class Form1
    Dim intDtrPay As Integer = 0
    Dim decAllTotalPay As Decimal = 0
    Dim intWorkerCounter As Integer = 0
    Dim intTotalOfPieces As Integer = 0
    Dim intAverageCounter As Integer = 0
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblStatusStrip.Text = "Programmed By: Gavin Lillard     " & Date.Now()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decQuanOfPay As Decimal = 0
        Dim strWorkerName As String = txtWorkersName.Text
        Dim decCurrentTotalPay As Decimal = 0
        intWorkerCounter += 1
        intAverageCounter += 1



        If txtNumberOfPieces.Text = "" Then
            MessageBox.Show("Please make sure both inputs have valid data within them", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)

        ElseIf IsNumeric(txtWorkersName.Text) Then
            MessageBox.Show("Please make sure both inputs have valid data within them", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)

        ElseIf txtWorkersName.Text = "" Then
            MessageBox.Show("Please make sure both inputs have valid data within them", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)

        ElseIf CInt(txtNumberOfPieces.Text) <= 0 Then
            MessageBox.Show("Please make sure the number of pieces is greater than 0", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

        intDtrPay = CInt(txtNumberOfPieces.Text)

        Select Case intDtrPay
            Case 1 To 199

                decQuanOfPay = 0.5D
                decCurrentTotalPay = Math.Round(intDtrPay * decQuanOfPay)
                lblPayOutput.Text = "Pay per completed piece: $0.50" & Environment.NewLine & "Total of Pay for " & txtWorkersName.Text & ": " & decCurrentTotalPay.ToString("C")


            Case 200 To 399

                decQuanOfPay = 0.55D
                decCurrentTotalPay = Math.Round(intDtrPay * decQuanOfPay)
                lblPayOutput.Text = "Pay per completed piece: $0.55" & Environment.NewLine & "Total of Pay for " & txtWorkersName.Text & ": " & decCurrentTotalPay.ToString("C")

            Case 400 To 599

                decQuanOfPay = 0.6D
                decCurrentTotalPay = Math.Round(intDtrPay * decQuanOfPay)
                lblPayOutput.Text = "Pay per completed piece: $0.60" & Environment.NewLine & "Total of Pay for " & txtWorkersName.Text & ": " & decCurrentTotalPay.ToString("C")


            Case Is >= 600

                decQuanOfPay = 0.65D
                decCurrentTotalPay = Math.Round(intDtrPay * decQuanOfPay)
                lblPayOutput.Text = "Pay per completed piece: $0.65" & Environment.NewLine & "Total of Pay for " & txtWorkersName.Text & ": " & decCurrentTotalPay.ToString("C")
            Case Else
                decQuanOfPay = 0.0D

        End Select
        intTotalOfPieces += intDtrPay
        decAllTotalPay += decCurrentTotalPay
    End Sub

    Private Sub btnSummary_Click(sender As Object, e As EventArgs) Handles btnSummary.Click
        MessageBox.Show("Total number of Pieces: " & intTotalOfPieces & Environment.NewLine & "Total Pay: " & decAllTotalPay.ToString("C") & Environment.NewLine & "Average Pay: " & Math.Round(decAllTotalPay / intAverageCounter).ToString("C") & Environment.NewLine & "Total number of Workers: " & intWorkerCounter, "Summary", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNumberOfPieces.Text = ""
        txtWorkersName.Text = ""
        txtWorkersName.Focus()
    End Sub

    Private Sub btnClearAll_Click(sender As Object, e As EventArgs) Handles btnClearAll.Click
        txtNumberOfPieces.Text = ""
        txtWorkersName.Text = ""
        decAllTotalPay = 0
        intAverageCounter = 0
        intWorkerCounter = 0
        txtWorkersName.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
