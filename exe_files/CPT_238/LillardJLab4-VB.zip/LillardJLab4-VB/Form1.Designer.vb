﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblStatusStrip = New System.Windows.Forms.ToolStripStatusLabel()
        Me.txtWorkersName = New System.Windows.Forms.TextBox()
        Me.txtNumberOfPieces = New System.Windows.Forms.TextBox()
        Me.lblWorkersName = New System.Windows.Forms.Label()
        Me.lblNumberOfPieces = New System.Windows.Forms.Label()
        Me.lblPayOutput = New System.Windows.Forms.Label()
        Me.lblForWorkersPay = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnSummary = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatusStrip})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 146)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(495, 22)
        Me.StatusStrip1.TabIndex = 0
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblStatusStrip
        '
        Me.lblStatusStrip.Name = "lblStatusStrip"
        Me.lblStatusStrip.Size = New System.Drawing.Size(0, 17)
        '
        'txtWorkersName
        '
        Me.txtWorkersName.Location = New System.Drawing.Point(101, 3)
        Me.txtWorkersName.Name = "txtWorkersName"
        Me.txtWorkersName.Size = New System.Drawing.Size(100, 20)
        Me.txtWorkersName.TabIndex = 1
        '
        'txtNumberOfPieces
        '
        Me.txtNumberOfPieces.Location = New System.Drawing.Point(101, 36)
        Me.txtNumberOfPieces.Name = "txtNumberOfPieces"
        Me.txtNumberOfPieces.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberOfPieces.TabIndex = 2
        '
        'lblWorkersName
        '
        Me.lblWorkersName.AutoSize = True
        Me.lblWorkersName.Location = New System.Drawing.Point(12, 6)
        Me.lblWorkersName.Name = "lblWorkersName"
        Me.lblWorkersName.Size = New System.Drawing.Size(83, 13)
        Me.lblWorkersName.TabIndex = 3
        Me.lblWorkersName.Text = "Workers' Name:"
        '
        'lblNumberOfPieces
        '
        Me.lblNumberOfPieces.AutoSize = True
        Me.lblNumberOfPieces.Location = New System.Drawing.Point(-1, 39)
        Me.lblNumberOfPieces.Name = "lblNumberOfPieces"
        Me.lblNumberOfPieces.Size = New System.Drawing.Size(96, 13)
        Me.lblNumberOfPieces.TabIndex = 4
        Me.lblNumberOfPieces.Text = "Number Of Pieces:"
        '
        'lblPayOutput
        '
        Me.lblPayOutput.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblPayOutput.Location = New System.Drawing.Point(254, 36)
        Me.lblPayOutput.Name = "lblPayOutput"
        Me.lblPayOutput.Size = New System.Drawing.Size(205, 37)
        Me.lblPayOutput.TabIndex = 5
        Me.lblPayOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblForWorkersPay
        '
        Me.lblForWorkersPay.AutoSize = True
        Me.lblForWorkersPay.Location = New System.Drawing.Point(323, 6)
        Me.lblForWorkersPay.Name = "lblForWorkersPay"
        Me.lblForWorkersPay.Size = New System.Drawing.Size(68, 13)
        Me.lblForWorkersPay.TabIndex = 6
        Me.lblForWorkersPay.Text = "Workers Pay"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(128, 76)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(96, 33)
        Me.btnCalculate.TabIndex = 7
        Me.btnCalculate.Text = "Ca&lculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnSummary
        '
        Me.btnSummary.Location = New System.Drawing.Point(15, 77)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(96, 32)
        Me.btnSummary.TabIndex = 8
        Me.btnSummary.Text = "&Summary"
        Me.btnSummary.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClear.Location = New System.Drawing.Point(15, 115)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(96, 33)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClearAll
        '
        Me.btnClearAll.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClearAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClearAll.Location = New System.Drawing.Point(128, 115)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(96, 33)
        Me.btnClearAll.TabIndex = 10
        Me.btnClearAll.Text = "Clear&All"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnExit.Location = New System.Drawing.Point(308, 110)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(96, 33)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(495, 168)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSummary)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblForWorkersPay)
        Me.Controls.Add(Me.lblPayOutput)
        Me.Controls.Add(Me.lblNumberOfPieces)
        Me.Controls.Add(Me.lblWorkersName)
        Me.Controls.Add(Me.txtNumberOfPieces)
        Me.Controls.Add(Me.txtWorkersName)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Name = "Form1"
        Me.Text = "CPT212 - PieceWork"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents lblStatusStrip As ToolStripStatusLabel
    Friend WithEvents txtWorkersName As TextBox
    Friend WithEvents txtNumberOfPieces As TextBox
    Friend WithEvents lblWorkersName As Label
    Friend WithEvents lblNumberOfPieces As Label
    Friend WithEvents lblPayOutput As Label
    Friend WithEvents lblForWorkersPay As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnSummary As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnClearAll As Button
    Friend WithEvents btnExit As Button
End Class
