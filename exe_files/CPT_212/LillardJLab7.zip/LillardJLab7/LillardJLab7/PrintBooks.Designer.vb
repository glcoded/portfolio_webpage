﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrintBooks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxSelectPrint = New System.Windows.Forms.GroupBox()
        Me.lbxPrint = New System.Windows.Forms.ListBox()
        Me.btnAddBook = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.gbxSelectPrint.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxSelectPrint
        '
        Me.gbxSelectPrint.Controls.Add(Me.lbxPrint)
        Me.gbxSelectPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxSelectPrint.Location = New System.Drawing.Point(32, 32)
        Me.gbxSelectPrint.Name = "gbxSelectPrint"
        Me.gbxSelectPrint.Size = New System.Drawing.Size(734, 276)
        Me.gbxSelectPrint.TabIndex = 0
        Me.gbxSelectPrint.TabStop = False
        Me.gbxSelectPrint.Text = "Select a Print Book"
        '
        'lbxPrint
        '
        Me.lbxPrint.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbxPrint.FormattingEnabled = True
        Me.lbxPrint.ItemHeight = 24
        Me.lbxPrint.Location = New System.Drawing.Point(45, 52)
        Me.lbxPrint.Name = "lbxPrint"
        Me.lbxPrint.Size = New System.Drawing.Size(644, 172)
        Me.lbxPrint.TabIndex = 1
        '
        'btnAddBook
        '
        Me.btnAddBook.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnAddBook.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddBook.Location = New System.Drawing.Point(96, 330)
        Me.btnAddBook.Name = "btnAddBook"
        Me.btnAddBook.Size = New System.Drawing.Size(289, 90)
        Me.btnAddBook.TabIndex = 1
        Me.btnAddBook.Text = "Add Book to Cart"
        Me.btnAddBook.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(416, 330)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(289, 90)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'PrintBooks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddBook)
        Me.Controls.Add(Me.gbxSelectPrint)
        Me.Name = "PrintBooks"
        Me.Text = "PrintBooks"
        Me.gbxSelectPrint.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbxSelectPrint As GroupBox
    Friend WithEvents btnAddBook As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lbxPrint As ListBox
End Class
