﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.menuStripOne = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintBooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AudioBooksToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.gpxProductsSelected = New System.Windows.Forms.GroupBox()
        Me.lblOutputTotal = New System.Windows.Forms.Label()
        Me.lblOutputTax = New System.Windows.Forms.Label()
        Me.lblOutputShipping = New System.Windows.Forms.Label()
        Me.lblOutputSubtotal = New System.Windows.Forms.Label()
        Me.lbxOutput = New System.Windows.Forms.ListBox()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblShipping = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.menuStripOne.SuspendLayout()
        Me.gpxProductsSelected.SuspendLayout()
        Me.SuspendLayout()
        '
        'menuStripOne
        '
        Me.menuStripOne.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.ProductsToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.menuStripOne.Location = New System.Drawing.Point(0, 0)
        Me.menuStripOne.Name = "menuStripOne"
        Me.menuStripOne.Size = New System.Drawing.Size(698, 24)
        Me.menuStripOne.TabIndex = 0
        Me.menuStripOne.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResetToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.FileToolStripMenuItem.Text = "&File "
        '
        'ResetToolStripMenuItem
        '
        Me.ResetToolStripMenuItem.Name = "ResetToolStripMenuItem"
        Me.ResetToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ResetToolStripMenuItem.Text = "R&eset"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'ProductsToolStripMenuItem
        '
        Me.ProductsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrintBooksToolStripMenuItem, Me.AudioBooksToolStripMenuItem})
        Me.ProductsToolStripMenuItem.Name = "ProductsToolStripMenuItem"
        Me.ProductsToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.ProductsToolStripMenuItem.Text = "&Products"
        '
        'PrintBooksToolStripMenuItem
        '
        Me.PrintBooksToolStripMenuItem.Name = "PrintBooksToolStripMenuItem"
        Me.PrintBooksToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.PrintBooksToolStripMenuItem.Text = "P&rint Books"
        '
        'AudioBooksToolStripMenuItem
        '
        Me.AudioBooksToolStripMenuItem.Name = "AudioBooksToolStripMenuItem"
        Me.AudioBooksToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.AudioBooksToolStripMenuItem.Text = "&Audio Books"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.BackColor = System.Drawing.SystemColors.MenuBar
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "&Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.AboutToolStripMenuItem.Text = "&About"
        '
        'gpxProductsSelected
        '
        Me.gpxProductsSelected.Controls.Add(Me.lblOutputTotal)
        Me.gpxProductsSelected.Controls.Add(Me.lblOutputTax)
        Me.gpxProductsSelected.Controls.Add(Me.lblOutputShipping)
        Me.gpxProductsSelected.Controls.Add(Me.lblOutputSubtotal)
        Me.gpxProductsSelected.Controls.Add(Me.lbxOutput)
        Me.gpxProductsSelected.Controls.Add(Me.btnRemove)
        Me.gpxProductsSelected.Controls.Add(Me.lblTotal)
        Me.gpxProductsSelected.Controls.Add(Me.lblShipping)
        Me.gpxProductsSelected.Controls.Add(Me.lblTax)
        Me.gpxProductsSelected.Controls.Add(Me.lblSubtotal)
        Me.gpxProductsSelected.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.gpxProductsSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gpxProductsSelected.Location = New System.Drawing.Point(12, 38)
        Me.gpxProductsSelected.Name = "gpxProductsSelected"
        Me.gpxProductsSelected.Size = New System.Drawing.Size(674, 388)
        Me.gpxProductsSelected.TabIndex = 1
        Me.gpxProductsSelected.TabStop = False
        Me.gpxProductsSelected.Text = "Products Selected"
        '
        'lblOutputTotal
        '
        Me.lblOutputTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputTotal.Location = New System.Drawing.Point(536, 216)
        Me.lblOutputTotal.Name = "lblOutputTotal"
        Me.lblOutputTotal.Size = New System.Drawing.Size(132, 51)
        Me.lblOutputTotal.TabIndex = 14
        Me.lblOutputTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOutputTax
        '
        Me.lblOutputTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputTax.Location = New System.Drawing.Point(536, 74)
        Me.lblOutputTax.Name = "lblOutputTax"
        Me.lblOutputTax.Size = New System.Drawing.Size(132, 51)
        Me.lblOutputTax.TabIndex = 13
        Me.lblOutputTax.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOutputShipping
        '
        Me.lblOutputShipping.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputShipping.Location = New System.Drawing.Point(536, 152)
        Me.lblOutputShipping.Name = "lblOutputShipping"
        Me.lblOutputShipping.Size = New System.Drawing.Size(132, 51)
        Me.lblOutputShipping.TabIndex = 12
        Me.lblOutputShipping.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOutputSubtotal
        '
        Me.lblOutputSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputSubtotal.Location = New System.Drawing.Point(536, 13)
        Me.lblOutputSubtotal.Name = "lblOutputSubtotal"
        Me.lblOutputSubtotal.Size = New System.Drawing.Size(132, 51)
        Me.lblOutputSubtotal.TabIndex = 11
        Me.lblOutputSubtotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbxOutput
        '
        Me.lbxOutput.FormattingEnabled = True
        Me.lbxOutput.ItemHeight = 20
        Me.lbxOutput.Location = New System.Drawing.Point(3, 22)
        Me.lbxOutput.Name = "lbxOutput"
        Me.lbxOutput.Size = New System.Drawing.Size(426, 224)
        Me.lbxOutput.TabIndex = 10
        '
        'btnRemove
        '
        Me.btnRemove.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnRemove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnRemove.Location = New System.Drawing.Point(90, 275)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(244, 70)
        Me.btnRemove.TabIndex = 9
        Me.btnRemove.Text = "Remove"
        Me.btnRemove.UseVisualStyleBackColor = False
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(470, 231)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(48, 20)
        Me.lblTotal.TabIndex = 8
        Me.lblTotal.Text = "Total:"
        '
        'lblShipping
        '
        Me.lblShipping.AutoSize = True
        Me.lblShipping.Location = New System.Drawing.Point(443, 167)
        Me.lblShipping.Name = "lblShipping"
        Me.lblShipping.Size = New System.Drawing.Size(75, 20)
        Me.lblShipping.TabIndex = 7
        Me.lblShipping.Text = "Shipping:"
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.Location = New System.Drawing.Point(470, 89)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(38, 20)
        Me.lblTax.TabIndex = 6
        Me.lblTax.Text = "Tax:"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.AutoSize = True
        Me.lblSubtotal.Location = New System.Drawing.Point(445, 28)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(73, 20)
        Me.lblSubtotal.TabIndex = 5
        Me.lblSubtotal.Text = "Subtotal:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClientSize = New System.Drawing.Size(698, 450)
        Me.Controls.Add(Me.gpxProductsSelected)
        Me.Controls.Add(Me.menuStripOne)
        Me.MainMenuStrip = Me.menuStripOne
        Me.Name = "Form1"
        Me.Text = "Shopping Cart"
        Me.menuStripOne.ResumeLayout(False)
        Me.menuStripOne.PerformLayout()
        Me.gpxProductsSelected.ResumeLayout(False)
        Me.gpxProductsSelected.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents menuStripOne As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ProductsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents gpxProductsSelected As GroupBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblShipping As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents ResetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintBooksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AudioBooksToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnRemove As Button
    Friend WithEvents lbxOutput As ListBox
    Friend WithEvents lblOutputTotal As Label
    Friend WithEvents lblOutputTax As Label
    Friend WithEvents lblOutputShipping As Label
    Friend WithEvents lblOutputSubtotal As Label
End Class
