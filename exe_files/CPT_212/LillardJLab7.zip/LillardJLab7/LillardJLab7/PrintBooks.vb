﻿Option Strict On
Option Explicit On
'Programmed By: Gavin Lillard
'CPT 212

Imports System.Security.Cryptography.X509Certificates

Public Class PrintBooks
    Private Sub PrintBooks_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbxPrint.Items.Add("I Did It Your Way (Print)")
        lbxPrint.Items.Add("The History of Scotland (Print)")
        lbxPrint.Items.Add("Learn Calculus in One Day (Print)")
        lbxPrint.Items.Add("Feel the Stress (Print)")
    End Sub
    Private Sub btnAddBookToCart_Click(sender As Object, e As EventArgs) Handles btnAddBook.Click
        If lbxPrint.SelectedItem IsNot Nothing Then
            Dim selectedBook As String = lbxPrint.SelectedItem.ToString()
            Dim bookPrice As Decimal = 0.0D


            Select Case selectedBook
                Case "I Did It Your Way (Print)"
                    bookPrice = PrintBookOnePrice
                Case "The History of Scotland (Print)"
                    bookPrice = PrintBookTwoPrice
                Case "Learn Calculus in One Day (Print)"
                    bookPrice = PrintBookThreePrice
                Case "Feel the Stress (Print)"
                    bookPrice = PrintBookFourPrice
            End Select

            Dim mainForm As Form1 = DirectCast(Application.OpenForms("Form1"), Form1)
            mainForm.AddBookFromPrint(selectedBook, bookPrice)
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class