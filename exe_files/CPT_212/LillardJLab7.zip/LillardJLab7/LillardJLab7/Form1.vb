﻿'Programmed By: Gavin Lillard
'CPT 212

Option Strict On
Option Explicit On
Public Class Form1
    Private decSubTotal As Decimal = 0.0D
    Private decTaxAmount As Decimal = 0.0D
    Private decShippingAmount As Decimal = 0.0D
    Private decTotalAmountDue As Decimal = 0.0D

    Public Sub AddBookFromPrint(printBook As String, bookPrice As Decimal)
        lbxOutput.Items.Add(printBook)
        decSubTotal += bookPrice
        UpdateTotals()
    End Sub

    Public Sub AddBookFromAudio(audioBook As String, bookPrice As Decimal)
        lbxOutput.Items.Add(audioBook)
        decSubTotal += bookPrice
        UpdateTotals()
    End Sub

    Private Sub UpdateTotals()
        decTaxAmount = decSubTotal * TaxRate
        decShippingAmount = lbxOutput.Items.Count * ShippingCost
        decTotalAmountDue = decSubTotal + decTaxAmount + decShippingAmount

        lblOutputSubtotal.Text = decSubTotal.ToString("C")
        lblOutputTax.Text = decTaxAmount.ToString("C")
        lblOutputShipping.Text = decShippingAmount.ToString("C")
        lblOutputTotal.Text = decTotalAmountDue.ToString("C")
    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        If lbxOutput.SelectedItem IsNot Nothing Then
            Dim selectedBook As String = lbxOutput.SelectedItem.ToString()

            Dim bookPrice As Decimal

            Select Case selectedBook
                Case "I Did It Your Way (Print)"
                    bookPrice = 11.95D
                Case "The History of Scotland (Print)"
                    bookPrice = 14.5D
                Case "Learn Calculus in One Day (Print)"
                    bookPrice = 29.95D
                Case "Feel the Stress (Print)"
                    bookPrice = 18.5D
                Case "Learn Calculus in One Day (Audio)"
                    bookPrice = 29.95D
                Case "The History of Scotland (Audio)"
                    bookPrice = 14.5D
                Case "The Science of Body Language (Audio)"
                    bookPrice = 12.95D
                Case "Relaxation Techniques (Audio)"
                    bookPrice = 11.5D
            End Select

            lbxOutput.Items.Remove(selectedBook)

            decSubTotal -= bookPrice

            Dim taxAmount As Decimal = bookPrice * 0.06D
            Dim shippingAmount As Decimal = 2D
            decTotalAmountDue -= (bookPrice + taxAmount + shippingAmount)

            UpdateTotals()
        End If
    End Sub

    Private Sub PrintBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintBooksToolStripMenuItem.Click
        Dim printForm As New PrintBooks
        printForm.ShowDialog()
    End Sub

    Private Sub AudioBooksToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AudioBooksToolStripMenuItem.Click
        Dim audioForm As New AudioBooks
        audioForm.ShowDialog()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MessageBox.Show("THIS IS MY SHOPPING CART APPLICATION", "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub ResetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetToolStripMenuItem.Click
        lbxOutput.Items.Clear()
        decSubTotal = 0.0D
        UpdateTotals()
    End Sub
End Class
