﻿Module ShoppingCartModule
    Public SelectedBookName As String
    Public SelectedBookPrice As Decimal
    Public Const PrintBookOnePrice As Decimal = 11.95D
    Public Const PrintBookTwoPrice As Decimal = 14.5D
    Public Const PrintBookThreePrice As Decimal = 29.95D
    Public Const PrintBookFourPrice As Decimal = 18.5D

    Public Const AudioBookOnePrice As Decimal = 29.95D
    Public Const AudioBookTwoPrice As Decimal = 14.5D
    Public Const AudioBookThreePrice As Decimal = 12.95D
    Public Const AudioBookFourPrice As Decimal = 11.5D

    Public Const TaxRate As Decimal = 0.06D

    Public Const ShippingCost As Decimal = 2D
End Module
