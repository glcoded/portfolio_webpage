﻿
'Programmed By: Gavin Lillard
'CPT 212

Option Strict On
Option Explicit On

Public Class AudioBooks
    Private Sub AudioBooks_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbxAudio.Items.Add("Learn Calculus in One Day (Audio)")
        lbxAudio.Items.Add("The History of Scotland (Audio)")
        lbxAudio.Items.Add("The Science of Body Language (Audio)")
        lbxAudio.Items.Add("Relaxation Techniques (Audio)")
    End Sub
    Private Sub btnAddBookToCart_Click(sender As Object, e As EventArgs) Handles btnAddTwo.Click
        If lbxAudio.SelectedItem IsNot Nothing Then
            Dim selectedBook As String = lbxAudio.SelectedItem.ToString()
            Dim bookPrice As Decimal = 0.0D


            Select Case selectedBook
                Case "Learn Calculus in One Day (Audio)"
                    bookPrice = AudioBookOnePrice
                Case "The History of Scotland (Audio)"
                    bookPrice = AudioBookTwoPrice
                Case "The Science of Body Language (Audio)"
                    bookPrice = AudioBookThreePrice
                Case "Relaxation Techniques (Audio)"
                    bookPrice = AudioBookFourPrice
            End Select

            Dim mainForm As Form1 = DirectCast(Application.OpenForms("Form1"), Form1)
            mainForm.AddBookFromAudio(selectedBook, bookPrice)

        End If
    End Sub
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnCloseTwo.Click
        Me.Close()
    End Sub
End Class