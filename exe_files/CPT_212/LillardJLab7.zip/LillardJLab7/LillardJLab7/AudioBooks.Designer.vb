﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AudioBooks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxSelectAudio = New System.Windows.Forms.GroupBox()
        Me.lbxAudio = New System.Windows.Forms.ListBox()
        Me.btnCloseTwo = New System.Windows.Forms.Button()
        Me.btnAddTwo = New System.Windows.Forms.Button()
        Me.gbxSelectAudio.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxSelectAudio
        '
        Me.gbxSelectAudio.Controls.Add(Me.lbxAudio)
        Me.gbxSelectAudio.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxSelectAudio.Location = New System.Drawing.Point(33, 32)
        Me.gbxSelectAudio.Name = "gbxSelectAudio"
        Me.gbxSelectAudio.Size = New System.Drawing.Size(734, 276)
        Me.gbxSelectAudio.TabIndex = 1
        Me.gbxSelectAudio.TabStop = False
        Me.gbxSelectAudio.Text = "Select an Audio Book"
        '
        'lbxAudio
        '
        Me.lbxAudio.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbxAudio.FormattingEnabled = True
        Me.lbxAudio.ItemHeight = 24
        Me.lbxAudio.Location = New System.Drawing.Point(43, 46)
        Me.lbxAudio.Name = "lbxAudio"
        Me.lbxAudio.Size = New System.Drawing.Size(644, 172)
        Me.lbxAudio.TabIndex = 0
        '
        'btnCloseTwo
        '
        Me.btnCloseTwo.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnCloseTwo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCloseTwo.Location = New System.Drawing.Point(412, 331)
        Me.btnCloseTwo.Name = "btnCloseTwo"
        Me.btnCloseTwo.Size = New System.Drawing.Size(289, 90)
        Me.btnCloseTwo.TabIndex = 2
        Me.btnCloseTwo.Text = "Close"
        Me.btnCloseTwo.UseVisualStyleBackColor = False
        '
        'btnAddTwo
        '
        Me.btnAddTwo.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnAddTwo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddTwo.Location = New System.Drawing.Point(95, 331)
        Me.btnAddTwo.Name = "btnAddTwo"
        Me.btnAddTwo.Size = New System.Drawing.Size(289, 90)
        Me.btnAddTwo.TabIndex = 3
        Me.btnAddTwo.Text = "Add Book to Cart"
        Me.btnAddTwo.UseVisualStyleBackColor = False
        '
        'AudioBooks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnCloseTwo)
        Me.Controls.Add(Me.btnAddTwo)
        Me.Controls.Add(Me.gbxSelectAudio)
        Me.Name = "AudioBooks"
        Me.Text = "AudioBooks"
        Me.gbxSelectAudio.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbxSelectAudio As GroupBox
    Friend WithEvents btnCloseTwo As Button
    Friend WithEvents btnAddTwo As Button
    Friend WithEvents lbxAudio As ListBox
End Class
