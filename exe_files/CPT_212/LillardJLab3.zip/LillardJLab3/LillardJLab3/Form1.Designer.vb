﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtGroupName = New System.Windows.Forms.TextBox()
        Me.txtMinutes = New System.Windows.Forms.TextBox()
        Me.lblGroupName = New System.Windows.Forms.Label()
        Me.lblMinutes = New System.Windows.Forms.Label()
        Me.lblGroupRtOutput = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblGrpThreeOutputNG = New System.Windows.Forms.Label()
        Me.lblGrpThreeOutputAC = New System.Windows.Forms.Label()
        Me.lblGrpThreeOutputTC = New System.Windows.Forms.Label()
        Me.lblGrpTwoOutputNG = New System.Windows.Forms.Label()
        Me.lblGrpTwoOutputAC = New System.Windows.Forms.Label()
        Me.lblGrpTwoOutputTC = New System.Windows.Forms.Label()
        Me.lblGrpOneOutputNG = New System.Windows.Forms.Label()
        Me.lblGrpOneOutputAC = New System.Windows.Forms.Label()
        Me.lblGrpOneOutputTC = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTotalCharges = New System.Windows.Forms.Label()
        Me.lblGroupThree = New System.Windows.Forms.Label()
        Me.lblGroupTwo = New System.Windows.Forms.Label()
        Me.lblGroupOne = New System.Windows.Forms.Label()
        Me.btnExitForm = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.btnClearSummary = New System.Windows.Forms.Button()
        Me.btnClearGroupInputs = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtGroupName
        '
        Me.txtGroupName.Location = New System.Drawing.Point(267, 31)
        Me.txtGroupName.Name = "txtGroupName"
        Me.txtGroupName.Size = New System.Drawing.Size(124, 20)
        Me.txtGroupName.TabIndex = 0
        '
        'txtMinutes
        '
        Me.txtMinutes.Location = New System.Drawing.Point(267, 57)
        Me.txtMinutes.Name = "txtMinutes"
        Me.txtMinutes.Size = New System.Drawing.Size(124, 20)
        Me.txtMinutes.TabIndex = 1
        '
        'lblGroupName
        '
        Me.lblGroupName.AutoSize = True
        Me.lblGroupName.Location = New System.Drawing.Point(188, 31)
        Me.lblGroupName.Name = "lblGroupName"
        Me.lblGroupName.Size = New System.Drawing.Size(73, 13)
        Me.lblGroupName.TabIndex = 2
        Me.lblGroupName.Text = "Group Name: "
        '
        'lblMinutes
        '
        Me.lblMinutes.AutoSize = True
        Me.lblMinutes.Location = New System.Drawing.Point(211, 60)
        Me.lblMinutes.Name = "lblMinutes"
        Me.lblMinutes.Size = New System.Drawing.Size(50, 13)
        Me.lblMinutes.TabIndex = 3
        Me.lblMinutes.Text = "Minutes: "
        '
        'lblGroupRtOutput
        '
        Me.lblGroupRtOutput.AutoSize = True
        Me.lblGroupRtOutput.Location = New System.Drawing.Point(48, 47)
        Me.lblGroupRtOutput.Name = "lblGroupRtOutput"
        Me.lblGroupRtOutput.Size = New System.Drawing.Size(32, 13)
        Me.lblGroupRtOutput.TabIndex = 4
        Me.lblGroupRtOutput.Text = "xxxxx"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblGrpThreeOutputNG)
        Me.GroupBox1.Controls.Add(Me.lblGrpThreeOutputAC)
        Me.GroupBox1.Controls.Add(Me.lblGrpThreeOutputTC)
        Me.GroupBox1.Controls.Add(Me.lblGrpTwoOutputNG)
        Me.GroupBox1.Controls.Add(Me.lblGrpTwoOutputAC)
        Me.GroupBox1.Controls.Add(Me.lblGrpTwoOutputTC)
        Me.GroupBox1.Controls.Add(Me.lblGrpOneOutputNG)
        Me.GroupBox1.Controls.Add(Me.lblGrpOneOutputAC)
        Me.GroupBox1.Controls.Add(Me.lblGrpOneOutputTC)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.lblTotalCharges)
        Me.GroupBox1.Controls.Add(Me.lblGroupThree)
        Me.GroupBox1.Controls.Add(Me.lblGroupTwo)
        Me.GroupBox1.Controls.Add(Me.lblGroupOne)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 96)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(397, 214)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "GroupBox1"
        '
        'lblGrpThreeOutputNG
        '
        Me.lblGrpThreeOutputNG.AutoSize = True
        Me.lblGrpThreeOutputNG.Location = New System.Drawing.Point(312, 180)
        Me.lblGrpThreeOutputNG.Name = "lblGrpThreeOutputNG"
        Me.lblGrpThreeOutputNG.Size = New System.Drawing.Size(45, 13)
        Me.lblGrpThreeOutputNG.TabIndex = 14
        Me.lblGrpThreeOutputNG.Text = "Label15"
        '
        'lblGrpThreeOutputAC
        '
        Me.lblGrpThreeOutputAC.AutoSize = True
        Me.lblGrpThreeOutputAC.Location = New System.Drawing.Point(202, 180)
        Me.lblGrpThreeOutputAC.Name = "lblGrpThreeOutputAC"
        Me.lblGrpThreeOutputAC.Size = New System.Drawing.Size(41, 13)
        Me.lblGrpThreeOutputAC.TabIndex = 13
        Me.lblGrpThreeOutputAC.Text = "label14"
        '
        'lblGrpThreeOutputTC
        '
        Me.lblGrpThreeOutputTC.AutoSize = True
        Me.lblGrpThreeOutputTC.Location = New System.Drawing.Point(93, 180)
        Me.lblGrpThreeOutputTC.Name = "lblGrpThreeOutputTC"
        Me.lblGrpThreeOutputTC.Size = New System.Drawing.Size(45, 13)
        Me.lblGrpThreeOutputTC.TabIndex = 12
        Me.lblGrpThreeOutputTC.Text = "Label13"
        '
        'lblGrpTwoOutputNG
        '
        Me.lblGrpTwoOutputNG.AutoSize = True
        Me.lblGrpTwoOutputNG.Location = New System.Drawing.Point(312, 120)
        Me.lblGrpTwoOutputNG.Name = "lblGrpTwoOutputNG"
        Me.lblGrpTwoOutputNG.Size = New System.Drawing.Size(45, 13)
        Me.lblGrpTwoOutputNG.TabIndex = 11
        Me.lblGrpTwoOutputNG.Text = "Label12"
        '
        'lblGrpTwoOutputAC
        '
        Me.lblGrpTwoOutputAC.AutoSize = True
        Me.lblGrpTwoOutputAC.Location = New System.Drawing.Point(202, 120)
        Me.lblGrpTwoOutputAC.Name = "lblGrpTwoOutputAC"
        Me.lblGrpTwoOutputAC.Size = New System.Drawing.Size(45, 13)
        Me.lblGrpTwoOutputAC.TabIndex = 10
        Me.lblGrpTwoOutputAC.Text = "Label11"
        '
        'lblGrpTwoOutputTC
        '
        Me.lblGrpTwoOutputTC.AutoSize = True
        Me.lblGrpTwoOutputTC.Location = New System.Drawing.Point(99, 120)
        Me.lblGrpTwoOutputTC.Name = "lblGrpTwoOutputTC"
        Me.lblGrpTwoOutputTC.Size = New System.Drawing.Size(45, 13)
        Me.lblGrpTwoOutputTC.TabIndex = 9
        Me.lblGrpTwoOutputTC.Text = "Label10"
        '
        'lblGrpOneOutputNG
        '
        Me.lblGrpOneOutputNG.AutoSize = True
        Me.lblGrpOneOutputNG.Location = New System.Drawing.Point(318, 59)
        Me.lblGrpOneOutputNG.Name = "lblGrpOneOutputNG"
        Me.lblGrpOneOutputNG.Size = New System.Drawing.Size(39, 13)
        Me.lblGrpOneOutputNG.TabIndex = 8
        Me.lblGrpOneOutputNG.Text = "Label9"
        '
        'lblGrpOneOutputAC
        '
        Me.lblGrpOneOutputAC.AutoSize = True
        Me.lblGrpOneOutputAC.Location = New System.Drawing.Point(208, 59)
        Me.lblGrpOneOutputAC.Name = "lblGrpOneOutputAC"
        Me.lblGrpOneOutputAC.Size = New System.Drawing.Size(39, 13)
        Me.lblGrpOneOutputAC.TabIndex = 7
        Me.lblGrpOneOutputAC.Text = "Label8"
        '
        'lblGrpOneOutputTC
        '
        Me.lblGrpOneOutputTC.AutoSize = True
        Me.lblGrpOneOutputTC.Location = New System.Drawing.Point(99, 59)
        Me.lblGrpOneOutputTC.Name = "lblGrpOneOutputTC"
        Me.lblGrpOneOutputTC.Size = New System.Drawing.Size(39, 13)
        Me.lblGrpOneOutputTC.TabIndex = 6
        Me.lblGrpOneOutputTC.Text = "Label7"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(291, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Number of Group"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(185, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Average Charges"
        '
        'lblTotalCharges
        '
        Me.lblTotalCharges.AutoSize = True
        Me.lblTotalCharges.Location = New System.Drawing.Point(83, 16)
        Me.lblTotalCharges.Name = "lblTotalCharges"
        Me.lblTotalCharges.Size = New System.Drawing.Size(70, 13)
        Me.lblTotalCharges.TabIndex = 3
        Me.lblTotalCharges.Text = "TotalCharges"
        '
        'lblGroupThree
        '
        Me.lblGroupThree.AutoSize = True
        Me.lblGroupThree.Location = New System.Drawing.Point(9, 180)
        Me.lblGroupThree.Name = "lblGroupThree"
        Me.lblGroupThree.Size = New System.Drawing.Size(22, 13)
        Me.lblGroupThree.TabIndex = 2
        Me.lblGroupThree.Text = "xxx"
        '
        'lblGroupTwo
        '
        Me.lblGroupTwo.AutoSize = True
        Me.lblGroupTwo.Location = New System.Drawing.Point(9, 120)
        Me.lblGroupTwo.Name = "lblGroupTwo"
        Me.lblGroupTwo.Size = New System.Drawing.Size(22, 13)
        Me.lblGroupTwo.TabIndex = 1
        Me.lblGroupTwo.Text = "xxx"
        '
        'lblGroupOne
        '
        Me.lblGroupOne.AutoSize = True
        Me.lblGroupOne.Location = New System.Drawing.Point(9, 59)
        Me.lblGroupOne.Name = "lblGroupOne"
        Me.lblGroupOne.Size = New System.Drawing.Size(22, 13)
        Me.lblGroupOne.TabIndex = 0
        Me.lblGroupOne.Text = "xxx"
        '
        'btnExitForm
        '
        Me.btnExitForm.Location = New System.Drawing.Point(289, 316)
        Me.btnExitForm.Name = "btnExitForm"
        Me.btnExitForm.Size = New System.Drawing.Size(111, 83)
        Me.btnExitForm.TabIndex = 6
        Me.btnExitForm.Text = "Exit"
        Me.btnExitForm.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 428)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(403, 22)
        Me.StatusStrip1.TabIndex = 7
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'btnClearSummary
        '
        Me.btnClearSummary.Location = New System.Drawing.Point(150, 316)
        Me.btnClearSummary.Name = "btnClearSummary"
        Me.btnClearSummary.Size = New System.Drawing.Size(111, 83)
        Me.btnClearSummary.TabIndex = 8
        Me.btnClearSummary.Text = "Clear Summary"
        Me.btnClearSummary.UseVisualStyleBackColor = True
        '
        'btnClearGroupInputs
        '
        Me.btnClearGroupInputs.Location = New System.Drawing.Point(3, 316)
        Me.btnClearGroupInputs.Name = "btnClearGroupInputs"
        Me.btnClearGroupInputs.Size = New System.Drawing.Size(111, 83)
        Me.btnClearGroupInputs.TabIndex = 9
        Me.btnClearGroupInputs.Text = "Clear Inputs"
        Me.btnClearGroupInputs.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(403, 450)
        Me.Controls.Add(Me.btnClearGroupInputs)
        Me.Controls.Add(Me.btnClearSummary)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btnExitForm)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblGroupRtOutput)
        Me.Controls.Add(Me.lblMinutes)
        Me.Controls.Add(Me.lblGroupName)
        Me.Controls.Add(Me.txtMinutes)
        Me.Controls.Add(Me.txtGroupName)
        Me.Name = "Form1"
        Me.Text = "Music and Minutes"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtGroupName As TextBox
    Friend WithEvents txtMinutes As TextBox
    Friend WithEvents lblGroupName As Label
    Friend WithEvents lblMinutes As Label
    Friend WithEvents lblGroupRtOutput As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblGroupThree As Label
    Friend WithEvents lblGroupTwo As Label
    Friend WithEvents lblGroupOne As Label
    Friend WithEvents lblGrpThreeOutputNG As Label
    Friend WithEvents lblGrpThreeOutputAC As Label
    Friend WithEvents lblGrpThreeOutputTC As Label
    Friend WithEvents lblGrpTwoOutputNG As Label
    Friend WithEvents lblGrpTwoOutputAC As Label
    Friend WithEvents lblGrpTwoOutputTC As Label
    Friend WithEvents lblGrpOneOutputNG As Label
    Friend WithEvents lblGrpOneOutputAC As Label
    Friend WithEvents lblGrpOneOutputTC As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTotalCharges As Label
    Friend WithEvents btnExitForm As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents btnClearSummary As Button
    Friend WithEvents btnClearGroupInputs As Button
End Class
