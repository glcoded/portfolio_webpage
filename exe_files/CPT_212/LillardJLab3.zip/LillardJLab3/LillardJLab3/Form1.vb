﻿'Programmed by Gavin Lillard
'09/06/24



Option Strict On
Option Explicit On

Public Class Form1
    Private Sub btnExitForm_Click(sender As Object, e As EventArgs) Handles btnExitForm.Click
        Me.Close()
    End Sub
End Class
