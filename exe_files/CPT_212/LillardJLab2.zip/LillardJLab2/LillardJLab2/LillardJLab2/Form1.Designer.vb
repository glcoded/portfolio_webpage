﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.picMailingLogo = New System.Windows.Forms.PictureBox()
        Me.cbxLogo = New System.Windows.Forms.CheckBox()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblStreetName = New System.Windows.Forms.Label()
        Me.lblStateName = New System.Windows.Forms.Label()
        Me.lblZipCode = New System.Windows.Forms.Label()
        Me.btnDisplayMessage = New System.Windows.Forms.Button()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtStreetName = New System.Windows.Forms.TextBox()
        Me.txtStateName = New System.Windows.Forms.TextBox()
        Me.mtxtZipCode = New System.Windows.Forms.MaskedTextBox()
        Me.btnNewUser = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblCityName = New System.Windows.Forms.Label()
        Me.txtCityName = New System.Windows.Forms.TextBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblStatusStrip = New System.Windows.Forms.ToolStripStatusLabel()
        CType(Me.picMailingLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'picMailingLogo
        '
        Me.picMailingLogo.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.picMailingLogo.Image = CType(resources.GetObject("picMailingLogo.Image"), System.Drawing.Image)
        Me.picMailingLogo.Location = New System.Drawing.Point(40, 38)
        Me.picMailingLogo.Name = "picMailingLogo"
        Me.picMailingLogo.Size = New System.Drawing.Size(339, 351)
        Me.picMailingLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picMailingLogo.TabIndex = 0
        Me.picMailingLogo.TabStop = False
        '
        'cbxLogo
        '
        Me.cbxLogo.AutoSize = True
        Me.cbxLogo.Checked = True
        Me.cbxLogo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbxLogo.Location = New System.Drawing.Point(342, 395)
        Me.cbxLogo.Name = "cbxLogo"
        Me.cbxLogo.Size = New System.Drawing.Size(86, 17)
        Me.cbxLogo.TabIndex = 8
        Me.cbxLogo.Text = "Show Logo?"
        Me.cbxLogo.UseVisualStyleBackColor = True
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.BackColor = System.Drawing.Color.Transparent
        Me.lblFirstName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstName.Location = New System.Drawing.Point(80, 67)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(80, 17)
        Me.lblFirstName.TabIndex = 10
        Me.lblFirstName.Text = "First Name:"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.BackColor = System.Drawing.Color.Transparent
        Me.lblLastName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastName.Location = New System.Drawing.Point(80, 93)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(80, 17)
        Me.lblLastName.TabIndex = 11
        Me.lblLastName.Text = "Last Name:"
        '
        'lblStreetName
        '
        Me.lblStreetName.AutoSize = True
        Me.lblStreetName.BackColor = System.Drawing.Color.Transparent
        Me.lblStreetName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStreetName.Location = New System.Drawing.Point(82, 119)
        Me.lblStreetName.Name = "lblStreetName"
        Me.lblStreetName.Size = New System.Drawing.Size(50, 17)
        Me.lblStreetName.TabIndex = 12
        Me.lblStreetName.Text = "Street:"
        '
        'lblStateName
        '
        Me.lblStateName.AutoSize = True
        Me.lblStateName.BackColor = System.Drawing.Color.Transparent
        Me.lblStateName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStateName.Location = New System.Drawing.Point(115, 146)
        Me.lblStateName.Name = "lblStateName"
        Me.lblStateName.Size = New System.Drawing.Size(45, 17)
        Me.lblStateName.TabIndex = 13
        Me.lblStateName.Text = "State:"
        '
        'lblZipCode
        '
        Me.lblZipCode.AutoSize = True
        Me.lblZipCode.BackColor = System.Drawing.Color.Transparent
        Me.lblZipCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZipCode.Location = New System.Drawing.Point(91, 203)
        Me.lblZipCode.Name = "lblZipCode"
        Me.lblZipCode.Size = New System.Drawing.Size(69, 17)
        Me.lblZipCode.TabIndex = 15
        Me.lblZipCode.Text = "Zip Code:"
        '
        'btnDisplayMessage
        '
        Me.btnDisplayMessage.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnDisplayMessage.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnDisplayMessage.FlatAppearance.BorderSize = 4
        Me.btnDisplayMessage.Location = New System.Drawing.Point(108, 347)
        Me.btnDisplayMessage.Name = "btnDisplayMessage"
        Me.btnDisplayMessage.Size = New System.Drawing.Size(213, 42)
        Me.btnDisplayMessage.TabIndex = 6
        Me.btnDisplayMessage.Text = "Enter"
        Me.btnDisplayMessage.UseVisualStyleBackColor = False
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(166, 67)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(131, 20)
        Me.txtFirstName.TabIndex = 0
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(166, 93)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(130, 20)
        Me.txtLastName.TabIndex = 1
        '
        'txtStreetName
        '
        Me.txtStreetName.Location = New System.Drawing.Point(138, 119)
        Me.txtStreetName.Name = "txtStreetName"
        Me.txtStreetName.Size = New System.Drawing.Size(183, 20)
        Me.txtStreetName.TabIndex = 2
        '
        'txtStateName
        '
        Me.txtStateName.Location = New System.Drawing.Point(166, 143)
        Me.txtStateName.Name = "txtStateName"
        Me.txtStateName.Size = New System.Drawing.Size(130, 20)
        Me.txtStateName.TabIndex = 3
        '
        'mtxtZipCode
        '
        Me.mtxtZipCode.Location = New System.Drawing.Point(166, 200)
        Me.mtxtZipCode.Mask = "00000-9999"
        Me.mtxtZipCode.Name = "mtxtZipCode"
        Me.mtxtZipCode.Size = New System.Drawing.Size(79, 20)
        Me.mtxtZipCode.TabIndex = 5
        '
        'btnNewUser
        '
        Me.btnNewUser.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnNewUser.Location = New System.Drawing.Point(40, 347)
        Me.btnNewUser.Name = "btnNewUser"
        Me.btnNewUser.Size = New System.Drawing.Size(62, 42)
        Me.btnNewUser.TabIndex = 7
        Me.btnNewUser.Text = "New"
        Me.btnNewUser.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnExit.Location = New System.Drawing.Point(327, 347)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(52, 42)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'lblCityName
        '
        Me.lblCityName.AutoSize = True
        Me.lblCityName.BackColor = System.Drawing.Color.Transparent
        Me.lblCityName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCityName.Location = New System.Drawing.Point(122, 172)
        Me.lblCityName.Name = "lblCityName"
        Me.lblCityName.Size = New System.Drawing.Size(35, 17)
        Me.lblCityName.TabIndex = 14
        Me.lblCityName.Text = "City:"
        '
        'txtCityName
        '
        Me.txtCityName.Location = New System.Drawing.Point(166, 174)
        Me.txtCityName.Name = "txtCityName"
        Me.txtCityName.Size = New System.Drawing.Size(130, 20)
        Me.txtCityName.TabIndex = 4
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatusStrip})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 428)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(429, 22)
        Me.StatusStrip1.TabIndex = 16
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblStatusStrip
        '
        Me.lblStatusStrip.Name = "lblStatusStrip"
        Me.lblStatusStrip.Size = New System.Drawing.Size(119, 17)
        Me.lblStatusStrip.Text = "ToolStripStatusLabel1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(429, 450)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.txtCityName)
        Me.Controls.Add(Me.lblCityName)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnNewUser)
        Me.Controls.Add(Me.mtxtZipCode)
        Me.Controls.Add(Me.txtStateName)
        Me.Controls.Add(Me.txtStreetName)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.btnDisplayMessage)
        Me.Controls.Add(Me.lblZipCode)
        Me.Controls.Add(Me.lblStateName)
        Me.Controls.Add(Me.lblStreetName)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.cbxLogo)
        Me.Controls.Add(Me.picMailingLogo)
        Me.Name = "Form1"
        Me.Text = "Mailing Labels Form"
        CType(Me.picMailingLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picMailingLogo As PictureBox
    Friend WithEvents cbxLogo As CheckBox
    Friend WithEvents lblFirstName As Label
    Friend WithEvents lblLastName As Label
    Friend WithEvents lblStreetName As Label
    Friend WithEvents lblStateName As Label
    Friend WithEvents lblZipCode As Label
    Friend WithEvents btnDisplayMessage As Button
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtStreetName As TextBox
    Friend WithEvents txtStateName As TextBox
    Friend WithEvents mtxtZipCode As MaskedTextBox
    Friend WithEvents btnNewUser As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblCityName As Label
    Friend WithEvents txtCityName As TextBox
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents lblStatusStrip As ToolStripStatusLabel
End Class
