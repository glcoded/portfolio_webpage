﻿'CPT 212 Lab 2: Mailing Labels
'Lillard, Joshua Gavin
'8/26/24
Option Explicit On
Option Strict On


Public Class Form1
    Private Sub cbxLogo_CheckedChanged(sender As Object, e As EventArgs) Handles cbxLogo.CheckedChanged
        picMailingLogo.Visible = cbxLogo.Checked
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Const strPROGRAMMER_NAME As String = "Gavin Lillard"

        lblStatusStrip.Text = "Programmed by: " & strPROGRAMMER_NAME

    End Sub

    Private Sub btnNewUser_Click(sender As Object, e As EventArgs) Handles btnNewUser.Click
        txtFirstName.Clear()
        txtLastName.Clear()
        txtStateName.Clear()
        txtStreetName.Clear()
        mtxtZipCode.Clear()
        txtCityName.Clear()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplayMessage_Click(sender As Object, e As EventArgs) Handles btnDisplayMessage.Click
        Dim strFirstName As String = ""
        Dim strLastName As String = ""
        Dim strStreetName As String = ""
        Dim strCityName As String = ""
        Dim strStateName As String = ""
        Dim strZipCode As String = ""
        Dim strOutput As String = ""

        Try
            strFirstName = txtFirstName.Text
            strLastName = txtLastName.Text
            strStreetName = txtStreetName.Text
            strCityName = txtCityName.Text
            strStateName = txtStateName.Text
            strZipCode = mtxtZipCode.Text

            strOutput = strFirstName & " " & strLastName & Environment.NewLine
            strOutput += strStreetName & Environment.NewLine
            strOutput += strCityName & ", " & strStateName & " " & strZipCode

            MessageBox.Show(strOutput, "Mailing Label", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Please try again and enter proper values.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try



    End Sub
End Class
