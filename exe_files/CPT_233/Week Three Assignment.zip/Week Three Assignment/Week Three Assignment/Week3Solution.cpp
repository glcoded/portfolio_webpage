#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

void sortArray(vector<int>* stewart);

int main()
{
	vector<int> gru;
	int userInput;

	for (int i = 0; i < 10; ++i) {
		cout << "Enter a number and press enter" << endl;
		cin >> userInput;
		gru.push_back(userInput);
	}
	
	
	sortArray(&gru);

	cout << "Sorted Array" << endl;
	for (int x : gru) {
		cout << x << " ";
	}

		system("pause");
		return 0;
}
void sortArray(vector<int>* stewart) {
	sort(stewart->begin(), stewart->end());

}