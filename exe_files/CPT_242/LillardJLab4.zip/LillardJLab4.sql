
/*1*/
USE books;
SELECT b.Title, p.Contact, p.Phone
FROM books b
JOIN publisher p ON b.PubID = p.PubID;

/*2*/
USE books;
SELECT CONCAT(c.Firstname , " " , c.Lastname) AS 'Customer Name', o.OrderDate, o.ShipDate
FROM customers c 
JOIN orders o ON c.customernum = o.customernum
WHERE o.ShipDate IS NULL
ORDER BY o.OrderDate;

/*3*/
USE vbauto;
SELECT CONCAT(c.FName, " " , c.LName) AS 'Customer Name', v.Manufacturer, v.ModelName
FROM vehicle v 
JOIN customer c ON v.InventoryID = c.InventoryIDNumber 
WHERE v.Manufacturer <> "Chevrolet" 
ORDER BY v.Manufacturer, v.ModelName;

/*4*/
USE books;
SELECT DISTINCT CONCAT(c.FirstName, " " , c.LastName) AS 'Customer Name' , b.Title
FROM Orders o 
LEFT JOIN customers c ON o.Customernum = c.Customernum
JOIN OrderItems i ON o.Ordernum = i.Ordernum
RIGHT JOIN Books b ON i.ISBN = b.ISBN
WHERE c.FirstName = "Jake";

/*5*/
USE vbvideo;
SELECT v.Title, v.Length, s.StudioName
FROM video v 
JOIN studio s ON v.StudioID = s.StudioID
ORDER BY v.Length DESC;

/*6*/
USE books;
SELECT a.ISBN, b.Title
FROM BookAuthor a
LEFT JOIN Books b ON a.ISBN = b.ISBN
RIGHT JOIN Author u ON a.AuthorID = u.AuthorID
WHERE u.LName = "Adams";

/*7*/
USE employee;
SELECT e.first_name, e.birth_date, t.tool_name, t.purchase_date, FLOOR(DATEDIFF(t.purchase_date, e.birth_date)/ 365.25) as 'Age at Purchase'
FROM employee e 
RIGHT JOIN tools t ON e.payroll_number = t.fk_payroll_number;

/*8*/
USE books;
SELECT DISTINCT CONCAT(u.Fname, " " , u.Lname) AS 'Author Name'
FROM Author u
LEFT JOIN BookAuthor a ON u.AuthorID = a.AuthorID
LEFT JOIN Books b ON a.ISBN = b.ISBN
LEFT JOIN OrderItems i ON b.ISBN = i.ISBN
LEFT JOIN Orders o ON i.Ordernum = o.Ordernum
LEFT JOIN Customers c ON o.Customernum = c.Customernum
WHERE c.Lastname = "Nelson" AND c.Firstname = "Becca";

/*9*/
USE books;
SELECT CONCAT(c.FirstName, " ", c.LastName) AS 'Customer Name', o.Ordernum, o.OrderDate
FROM customers c 
LEFT JOIN orders o ON c.Customernum = o.Customernum;

/*10*/
USE books;
SELECT b.Title, o.Ordernum, o.Quantity
FROM books b 
LEFT JOIN OrderItems o ON b.ISBN = o.ISBN
WHERE b.title LIKE '%A%A%'
ORDER BY o.Ordernum;



