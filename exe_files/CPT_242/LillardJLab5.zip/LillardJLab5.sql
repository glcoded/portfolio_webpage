/*1*/
USE books;
INSERT INTO Publisher  (PubID, Name, Contact, Phone)
VALUE ('6', 'Gavin Lillard', '456 NewGuy Lane', '1234556666');

INSERT INTO Author  (AuthorID, Lname, Fname)
VALUE ('X100', 'Lillard', 'Jaxon');
 
 INSERT INTO Books (ISBN, Title, PubDate, PubID, Cost, Retail, Category)
 VALUE (957413078, 'New Beginning', '1994-23-12',432, 20, 25.00, 'Fiction');
 
 INSERT INTO Customers (Customernum, LastName, FirstName, Address, City,State,Zip,Referred)
 VALUE (432, 'New', 'Man', '123 Lane', 'Nowhere', 'SC', '29803', 'No');
 
 INSERT INTO Orders (Ordernum, Customernum, OrderDate, ShipDate, ShipStreet, ShipCity, ShipState, ShipZip)
 VALUE(423523, 8583294, '2024-9-20', '2024-10-1', 'Circle Lane', 'StarDew', 'Valley', 'SC', '12344');


/*2*/
USE books;
DELETE FROM Publisher
WHERE PubID = 6;
DELETE FROM Author 
WHERE AuthorID = 'X100';
DELETE FROM Books 
WHERE ISBN = 957413078;
DELETE FROM Customers
WHERE Customernum = 432;
DELETE FROM Orders 
WHERE Ordernum = 423523;

/*3*/
USE lyric;
UPDATE SalesPeople
SET Base = 400.00
WHERE SalesID = 2;

/*4*/
USE lyric;
UPDATE SalesPeople
SET Base = (Base + 50.00)
WHERE FirstName = "Clint" AND LastName = "Sanchez";

/*5*/
USE lyric;
UPDATE Members
SET WorkPhone = HomePhone
WHERE MemberID = 13;

/*6*/
USE lyric;
UPDATE Titles
SET UPC = '4238619983', Genre = 'jazz'
WHERE Title = 'Word Live';

/*7*/
USE lyric;
UPDATE Members
SET MemberID = 3
WHERE Country = 'Canada' AND MemberID = 2

/*8*/
USE lyric;
UPDATE SalesPeople 
SET FirstName = LOWER(FirstName), LastName = LOWER(LastName);

/*9*/
USE cc;
UPDATE Customers 
SET cust_email = 'no email'
WHERE cust_email IS NULL;

/*10*/
USE cc;
UPDATE OrderItems
SET Quantity = Quantity * 2;